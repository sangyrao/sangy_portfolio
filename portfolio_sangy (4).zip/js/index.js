$(document).ready(function() {  
  $("#maincontainer").tabs();
});